package GUI.Schule;

public class Start {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        Oberflaeche o = new Oberflaeche();
    }

}
