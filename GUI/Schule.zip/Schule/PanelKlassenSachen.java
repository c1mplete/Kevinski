package GUI.Schule;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class PanelKlassenSachen extends JPanel implements ActionListener {
    Klasse KlasseFuerSchuelerOhneKlasse = new Klasse("S. Ohne K.", null);
    JLabel namePanel,
            nameKlassen,
            nameSchueler,
            funktionenLabel,
            matrikelNRLabel,
            schuelerKlasseLabel,
            nameSchuelerLabel,
            nachnameSchuelerLabel,
            nameKlasseLabel,
            nameKlassenlehrerLabel,
            anzahlSchuelerLabel,
            nameLehrerLabel,
            matrikelnrLehrerLabel;
    JComboBox<String> comboBoxKlassen, comboboxKlassen2;
    JComboBox<String> comboBoxSchueler;
    JComboBox comboBoxFunktionen;
    JButton btnSchuelerHinzufuegen,
            btnSchuelerLoeschen,
            btnSchuelerAendern,
            btnKlasseHinzufuegen,
            btnKlasseLoeschen,
            btnKlasseAendern    ;
    JTextField matrikelNRFeldText,
            name,
            nameKlassenlehrerFeld,
            anzahlSchuelerFeld,
            nameKlasseFeld,
            nachnameSchuelerFeld,
            nameLehrerFeld,
            matrikelnrLehrerFeld;

    public PanelKlassenSachen() {
        //!Main Panel
        this.setBounds(0, 0, 1000, 1000);
        this.setLayout(null);
        namePanel = new JLabel("PanelKlassenSachen");
        namePanel.setFont(new Font("Verdana",1,20));
        namePanel.setBounds(100, 10, 350, 30);
        namePanel.setHorizontalAlignment(JLabel.CENTER);

        //!Klassen JComboBox
        ArrayList<String> allClasses = Klasse.getAllClassNames();
        nameKlassen = new JLabel("Klassen");
        nameKlassen.setBounds(30, 30, 150, 20);
        DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>(allClasses.toArray(new String[0]));
        comboBoxKlassen = new JComboBox<>(model);
        comboBoxKlassen.setBounds(30, 50, 150, 20);
        nameKlassen.setLabelFor(comboBoxKlassen);
        this.add(comboBoxKlassen);
        this.add(nameKlassen);

        //!Schueler JComboBox
        ArrayList<Schueler> allSchueler = Schueler.getAllSchueler();
        nameSchueler = new JLabel("Schueler");
        nameSchueler.setBounds(450, 30, 150, 20);
        DefaultComboBoxModel<String> model2 = new DefaultComboBoxModel<>(allSchueler.toArray(new String[0]));
        comboBoxSchueler = new JComboBox<>(model2);
        comboBoxSchueler.setBounds(450, 50, 150, 20);
        nameSchueler.setLabelFor(comboBoxSchueler);
        comboBoxSchueler.addActionListener(this);
        this.add(comboBoxSchueler);
        this.add(nameSchueler);

        //!Funktionen
        funktionenLabel = new JLabel("Funktionen");
        funktionenLabel.setBounds(30, 100, 150, 20);
        funktionenLabel.setBackground(Color.BLACK);
        comboBoxFunktionen = new JComboBox();
        comboBoxFunktionen.addItem("Schueler");
        comboBoxFunktionen.addItem("Klasse");
        comboBoxFunktionen.addItem("Lehrer");
        comboBoxFunktionen.setBounds(30, 120, 150, 20);
        comboBoxFunktionen.addActionListener(this);
        funktionenLabel.setLabelFor(comboBoxFunktionen);
        this.add(comboBoxFunktionen);
        this.add(funktionenLabel);

        //!Felder bei Schueler Funktion
        nameSchuelerLabel = new JLabel("Name");
        nameSchuelerLabel.setBounds(250, 50, 150, 20);
        name = new JTextField();
        name.setBounds(250, 75, 150, 20);
        nameSchuelerLabel.setLabelFor(name);

        nachnameSchuelerLabel = new JLabel("Nachname");
        nachnameSchuelerLabel.setBounds(250, 100, 150, 20);
        nachnameSchuelerFeld = new JTextField();
        nachnameSchuelerFeld.setBounds(250, 125, 150, 20);

        matrikelNRLabel = new JLabel("MatrikelNR");
        matrikelNRLabel.setBounds(250, 150, 150, 20);
        matrikelNRFeldText = new JTextField();
        matrikelNRFeldText.setBounds(250, 175, 150, 20);
        matrikelNRLabel.setLabelFor(matrikelNRFeldText);

        comboboxKlassen2 = new JComboBox<>(model);
        comboboxKlassen2.setBounds(250, 225, 150, 20);
        schuelerKlasseLabel = new JLabel("Klasse");
        schuelerKlasseLabel.setBounds(250, 200, 150, 20);
        schuelerKlasseLabel.setLabelFor(comboboxKlassen2);

        btnSchuelerAendern = new JButton("Aendern");
        btnSchuelerAendern.setBounds(250, 250, 150, 20);
        btnSchuelerAendern.addActionListener(this);

        btnSchuelerHinzufuegen = new JButton("Hinzufuegen");
        btnSchuelerHinzufuegen.setBounds(250, 275, 150, 20);
        btnSchuelerHinzufuegen.addActionListener(this);

        btnSchuelerLoeschen = new JButton("Loeschen");
        btnSchuelerLoeschen.setBounds(250, 300, 150, 20);
        btnSchuelerLoeschen.addActionListener(this);



        this.add(btnSchuelerAendern);
        this.add(btnSchuelerHinzufuegen);
        this.add(btnSchuelerLoeschen);
        this.add(nameSchuelerLabel);
        this.add(name);
        this.add(matrikelNRLabel);
        this.add(matrikelNRFeldText);
        this.add(schuelerKlasseLabel);
        this.add(comboboxKlassen2);


        //!Felder bei Klasse Funktion
        nameKlasseLabel = new JLabel("Name K");
        nameKlasseLabel.setBounds(250, 50, 150, 20);
        nameKlasseFeld = new JTextField();
        nameKlasseFeld.setBounds(250, 75, 150, 20);
        nameKlasseLabel.setLabelFor(nameKlasseFeld);

        nameKlassenlehrerLabel = new JLabel("Klassenlehrer K");
        nameKlassenlehrerLabel.setBounds(250, 100, 150, 20);
        nameKlassenlehrerFeld = new JTextField();
        nameKlassenlehrerFeld.setBounds(250, 125, 150, 20);
        nameKlassenlehrerLabel.setLabelFor(nameKlassenlehrerFeld);

        anzahlSchuelerLabel = new JLabel("Anzahl Schueler K");
        anzahlSchuelerLabel.setBounds(250, 150, 150, 20);
        anzahlSchuelerFeld = new JTextField();
        anzahlSchuelerFeld.setVisible(false);
        anzahlSchuelerFeld.setBounds(250, 175, 150, 20);
        anzahlSchuelerLabel.setLabelFor(anzahlSchuelerFeld);
        anzahlSchuelerFeld.setEditable(false);

        btnKlasseAendern = new JButton("Aendern K");
        btnKlasseAendern.setBounds(250, 200, 150, 20);
        btnKlasseAendern.addActionListener(this);

        btnKlasseHinzufuegen = new JButton("Hinzufuegen K");
        btnKlasseHinzufuegen.setBounds(250, 225, 150, 20);
        btnKlasseHinzufuegen.addActionListener(this);

        btnKlasseLoeschen = new JButton("Loeschen K");
        btnKlasseLoeschen.setBounds(250, 250, 150, 20);
        btnKlasseLoeschen.addActionListener(this);

        this.add(btnKlasseAendern);
        this.add(btnKlasseHinzufuegen);
        this.add(btnKlasseLoeschen);
        this.add(nameKlasseLabel);
        this.add(nameKlasseFeld);
        this.add(nameKlassenlehrerLabel);
        this.add(nameKlassenlehrerFeld);
        this.add(anzahlSchuelerLabel);
        this.add(anzahlSchuelerFeld);
        this.add(nachnameSchuelerLabel);
        this.add(nachnameSchuelerFeld);

        nameKlasseLabel.setVisible(false);
        nameKlasseFeld.setVisible(false);
        nameKlassenlehrerLabel.setVisible(false);
        nameKlassenlehrerFeld.setVisible(false);
        anzahlSchuelerLabel.setVisible(false);
        anzahlSchuelerFeld.setVisible(false);
        btnKlasseHinzufuegen.setVisible(false);
        btnKlasseLoeschen.setVisible(false);
        btnKlasseAendern.setVisible(false);

        nameKlasseLabel.setVisible(false);
        nameKlasseFeld.setVisible(false);
        nameKlassenlehrerLabel.setVisible(false);
        nameKlassenlehrerFeld.setVisible(false);
        anzahlSchuelerLabel.setVisible(false);
        anzahlSchuelerFeld.setVisible(false);
        this.add(namePanel);
        this.setVisible(true);


    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(comboBoxFunktionen.getSelectedItem().equals("Schueler")) {
            comboBoxSchueler.setVisible(true);
            nameSchuelerLabel.setVisible(true);
            name.setVisible(true);
            matrikelNRLabel.setVisible(true);
            matrikelNRFeldText.setVisible(true);
            schuelerKlasseLabel.setVisible(true);
            nameSchueler.setVisible(true);
            nachnameSchuelerLabel.setVisible(true);
            nachnameSchuelerFeld.setVisible(true);
            btnSchuelerAendern.setVisible(true);
            btnSchuelerLoeschen.setVisible(true);
            btnSchuelerHinzufuegen.setVisible(true);
            comboboxKlassen2.setVisible(true);

            nameKlasseLabel.setVisible(false);
            nameKlasseFeld.setVisible(false);
            nameKlassenlehrerLabel.setVisible(false);
            nameKlassenlehrerFeld.setVisible(false);
            anzahlSchuelerLabel.setVisible(false);
            anzahlSchuelerFeld.setVisible(false);
            btnKlasseHinzufuegen.setVisible(false);
            btnKlasseLoeschen.setVisible(false);
            btnKlasseAendern.setVisible(false);
            this.revalidate();
            this.repaint();
        }
        if(comboBoxFunktionen.getSelectedItem().equals("Klasse")) {
            nameKlasseLabel.setVisible(true);
            nameKlasseFeld.setVisible(true);
            nameKlassenlehrerLabel.setVisible(true);
            nameKlassenlehrerFeld.setVisible(true);
            anzahlSchuelerLabel.setVisible(true);
            anzahlSchuelerFeld.setVisible(true);
            btnKlasseHinzufuegen.setVisible(true);
            btnKlasseLoeschen.setVisible(true);
            btnKlasseAendern.setVisible(true);

            comboBoxSchueler.setVisible(false);
            nameSchuelerLabel.setVisible(false);
            name.setVisible(false);
            matrikelNRLabel.setVisible(false);
            matrikelNRFeldText.setVisible(false);
            schuelerKlasseLabel.setVisible(false);
            nameSchueler.setVisible(false);
            nachnameSchuelerLabel.setVisible(false);
            nachnameSchuelerFeld.setVisible(false);
            btnSchuelerAendern.setVisible(false);
            btnSchuelerLoeschen.setVisible(false);
            btnSchuelerHinzufuegen.setVisible(false);
            comboboxKlassen2.setVisible(false);

            this.revalidate();
            this.repaint();
        }
        if(e.getSource() == btnSchuelerHinzufuegen) {
            String name = this.name.getText();
            String nachname = this.nachnameSchuelerFeld.getText();
            int matrikelNR = Integer.parseInt(this.matrikelNRFeldText.getText());
            Schueler s = new Schueler(name, nachname, matrikelNR);
            comboBoxSchueler.addItem(s.getNachname());
            comboBoxSchueler.setSelectedItem(s.getNachname());
            this.revalidate();
            this.repaint();
        }
        if(e.getSource() == btnSchuelerLoeschen) {
            String name = (String) comboBoxSchueler.getSelectedItem();
            Schueler.deleteSchueler(Schueler.getSchuelerByName(name).getMatrikelnr());
            comboBoxSchueler.removeItem(name);
            this.revalidate();
            this.repaint();
        }
        if(e.getSource() == btnSchuelerAendern) {
            String name = (String) comboBoxSchueler.getSelectedItem();
            String newName = this.name.getText();
            String newNachname = this.nachnameSchuelerFeld.getText();
            Schueler.updateSchueler(Schueler.getSchuelerByName(name).getMatrikelnr(), newName, newNachname);
            comboBoxSchueler.removeItem(name);
            comboBoxSchueler.addItem(newNachname);
            comboBoxSchueler.setSelectedItem(newNachname);
            this.revalidate();
            this.repaint();
        }
        if(e.getSource() == comboBoxSchueler) {
            String name = (String) comboBoxSchueler.getSelectedItem();
            Schueler s = Schueler.getSchuelerByName(name);
            this.name.setText(s.getVorname());
            this.nachnameSchuelerFeld.setText(s.getNachname());
            this.matrikelNRFeldText.setText(String.valueOf(s.getMatrikelnr()));
            this.revalidate();
            this.repaint();
        }


    }
}
